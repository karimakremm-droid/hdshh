@echo off
set DIR=%~dp0
set WRAPPER_JAR=%DIR%gradle\wrapper\gradle-wrapper.jar
if not exist "%WRAPPER_JAR%" (
  echo gradle-wrapper.jar not found.
  echo Open this project in Android Studio and let it sync - it will fetch the wrapper automatically.
  exit /b 1
)
java -jar "%WRAPPER_JAR%" %*
