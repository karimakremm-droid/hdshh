package com.equran.quranall;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.ImageButton;
import android.graphics.Color;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;

public class TadabburActivity extends AppCompatActivity {
    private WebView webView;
    private ProgressBar progressBar;
    private android.widget.LinearLayout offlineView;
    private String targetUrl;

    private boolean isOnline() {
        android.net.ConnectivityManager cm =
            (android.net.ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (cm == null) return true; // fail open — don't block loading on a check failure
        android.net.Network net = cm.getActiveNetwork();
        if (net == null) return false;
        android.net.NetworkCapabilities caps = cm.getNetworkCapabilities(net);
        return caps != null && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    private void tryLoad() {
        if (isOnline()) {
            offlineView.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            webView.loadUrl(targetUrl);
        } else {
            offlineView.setVisibility(View.VISIBLE);
            webView.setVisibility(View.GONE);
            progressBar.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#fdf6e3"));

        android.widget.LinearLayout header = new android.widget.LinearLayout(this);
        header.setBackgroundColor(Color.parseColor("#2d5a27"));
        header.setPadding(16, 12, 16, 12);
        header.setGravity(android.view.Gravity.CENTER_VERTICAL);

        ImageButton backBtn = new ImageButton(this);
        backBtn.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        backBtn.setBackground(null);
        backBtn.setColorFilter(Color.WHITE);
        backBtn.setOnClickListener(v -> finish());

        String screenTitle = getIntent().getStringExtra("title");
        if (screenTitle == null || screenTitle.isEmpty()) screenTitle = "🌿 القرآن تدبر وعمل";

        android.widget.TextView title = new android.widget.TextView(this);
        title.setText(screenTitle);
        title.setTextColor(Color.WHITE);
        title.setTextSize(16);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
            0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        title.setGravity(android.view.Gravity.CENTER);
        title.setTextDirection(View.TEXT_DIRECTION_RTL);

        header.addView(backBtn);
        header.addView(title);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.VISIBLE);
        android.widget.LinearLayout.LayoutParams pbParams = new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 4);
        progressBar.setLayoutParams(pbParams);

        webView = new WebView(this);
        android.widget.LinearLayout.LayoutParams wvParams = new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        webView.setLayoutParams(wvParams);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        // نفس الـ user-agent كالنسخة القديمة التي كانت تشتغل
        s.setUserAgentString(s.getUserAgentString() + " TadabburApp/1.0");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView view, android.webkit.WebResourceRequest request,
                                         android.webkit.WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    progressBar.setVisibility(View.GONE);
                    offlineView.setVisibility(View.VISIBLE);
                    webView.setVisibility(View.GONE);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int progress) {
                progressBar.setProgress(progress);
                progressBar.setVisibility(progress < 100 ? View.VISIBLE : View.GONE);
            }
        });

        // "No internet connection" state — shown instead of a blank/broken WebView
        // when there's no network, or when the main-frame request fails to load.
        offlineView = new android.widget.LinearLayout(this);
        offlineView.setOrientation(android.widget.LinearLayout.VERTICAL);
        offlineView.setGravity(android.view.Gravity.CENTER);
        offlineView.setPadding(40, 40, 40, 40);
        offlineView.setVisibility(View.GONE);
        android.widget.LinearLayout.LayoutParams offlineParams = new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        offlineView.setLayoutParams(offlineParams);

        android.widget.TextView offlineIcon = new android.widget.TextView(this);
        offlineIcon.setText("📡");
        offlineIcon.setTextSize(40);
        offlineIcon.setGravity(android.view.Gravity.CENTER);

        android.widget.TextView offlineText = new android.widget.TextView(this);
        offlineText.setText("أنت غير متصل بالإنترنت");
        offlineText.setTextColor(Color.parseColor("#7a6f4a"));
        offlineText.setTextSize(16);
        offlineText.setTypeface(null, android.graphics.Typeface.BOLD);
        offlineText.setGravity(android.view.Gravity.CENTER);
        offlineText.setTextDirection(View.TEXT_DIRECTION_RTL);
        offlineText.setPadding(0, 24, 0, 8);

        android.widget.TextView offlineSub = new android.widget.TextView(this);
        offlineSub.setText("يحتاج هذا القسم اتصالاً بالإنترنت لعرض المحتوى");
        offlineSub.setTextColor(Color.parseColor("#9a8f6a"));
        offlineSub.setTextSize(13);
        offlineSub.setGravity(android.view.Gravity.CENTER);
        offlineSub.setTextDirection(View.TEXT_DIRECTION_RTL);
        offlineSub.setPadding(0, 0, 0, 24);

        android.widget.Button retryBtn = new android.widget.Button(this);
        retryBtn.setText("إعادة المحاولة");
        retryBtn.setBackgroundColor(Color.parseColor("#1a6b3a"));
        retryBtn.setTextColor(Color.WHITE);
        retryBtn.setOnClickListener(v -> {
            progressBar.setVisibility(View.VISIBLE);
            tryLoad();
        });

        offlineView.addView(offlineIcon);
        offlineView.addView(offlineText);
        offlineView.addView(offlineSub);
        offlineView.addView(retryBtn);

        root.addView(header);
        root.addView(progressBar);
        root.addView(webView);
        root.addView(offlineView);
        setContentView(root);
        // Edge-to-edge (API 35+): pad root view by system bar insets so content isn't clipped.
        final android.view.View __rootInsetView = findViewById(android.R.id.content);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(__rootInsetView, (v, windowInsets) -> {
            androidx.core.graphics.Insets bars = windowInsets.getInsets(
                androidx.core.view.WindowInsetsCompat.Type.systemBars()
                    | androidx.core.view.WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return windowInsets;
        });


        targetUrl = getIntent().getStringExtra("url");
        if (targetUrl == null) targetUrl = "https://altadabbur.com/quran?page=1&verse=1";
        tryLoad();
    }

    @Override
    public void onBackPressed() {
        // This is a secondary/child window (opened from MainActivity to show
        // Tadabbur or an external explanation link) — a single back press
        // should close it immediately, exactly like the ✕ button does.
        finish();
    }
}
