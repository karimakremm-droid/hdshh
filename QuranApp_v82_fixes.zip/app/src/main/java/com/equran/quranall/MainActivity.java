package com.equran.quranall;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.view.WindowManager;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import androidx.webkit.WebViewAssetLoader;

import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private WebView webView;

    // ── Signing-certificate pinning (tamper / repackage detection) ─────────
    // Blank by default = disabled (never breaks your own debug/first builds).
    // To enable: build a signed release APK once, read the SHA-256 fingerprint
    // Android actually sees at runtime from Logcat (search tag "SigCheck" —
    // added below), then paste that value here. From then on, if anyone
    // decompiles this app, modifies assets/index.enc or the Java code, and
    // re-signs the APK with a DIFFERENT key (their own, since they don't have
    // yours), this check fails and the app refuses to decrypt/display content
    // instead of silently running the tampered copy.
    // NOTE: this raises the bar against casual repackaging/redistribution —
    // it is not, and cannot be, an absolute guarantee for any client-side app.
    private static final String EXPECTED_SIGNATURE_SHA256 = ""; // fill in to activate

    private boolean isSignatureValid() {
        if (EXPECTED_SIGNATURE_SHA256.isEmpty()) return true; // check disabled
        try {
            @SuppressWarnings("deprecation")
            PackageInfo info = getPackageManager().getPackageInfo(
                getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature sig : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] digest = md.digest(sig.toByteArray());
                StringBuilder sb = new StringBuilder();
                for (byte b : digest) sb.append(String.format("%02X", b));
                String fingerprint = sb.toString();
                android.util.Log.d("SigCheck", "Runtime signature SHA-256: " + fingerprint);
                if (fingerprint.equalsIgnoreCase(EXPECTED_SIGNATURE_SHA256)) return true;
            }
        } catch (Exception e) {
            android.util.Log.e("SigCheck", "Signature check failed", e);
        }
        return false;
    }

    // ── AES-256 key split across 4 segments to resist static analysis ─────────
    private static final byte[] _K1 = {
        (byte)0x9b, (byte)0xbb, (byte)0x0e, (byte)0xa3,
        (byte)0x11, (byte)0x2e, (byte)0xba, (byte)0xde
    };
    private static final byte[] _K2 = {
        (byte)0x1a, (byte)0xa4, (byte)0xa1, (byte)0xac,
        (byte)0x7b, (byte)0x5a, (byte)0xd4, (byte)0xf7
    };
    private static final byte[] _K3 = {
        (byte)0x1b, (byte)0x0d, (byte)0xb6, (byte)0x02,
        (byte)0x80, (byte)0x40, (byte)0xfa, (byte)0x06
    };
    private static final byte[] _K4 = {
        (byte)0x16, (byte)0x3b, (byte)0x60, (byte)0x95,
        (byte)0x48, (byte)0xe2, (byte)0xdf, (byte)0xb5
    };

    private static byte[] buildKey() {
        byte[] k = new byte[32];
        System.arraycopy(_K1, 0, k,  0, 8);
        System.arraycopy(_K2, 0, k,  8, 8);
        System.arraycopy(_K3, 0, k, 16, 8);
        System.arraycopy(_K4, 0, k, 24, 8);
        return k;
    }

    /** Decrypt assets/index.enc  →  HTML string */
    private String loadEncryptedPage() throws Exception {
        if (!isSignatureValid()) {
            // Refuse to decrypt content for a repackaged/re-signed APK.
            return "<html><body style='background:#fdf6e3;display:flex;align-items:center;" +
                   "justify-content:center;height:100vh;margin:0;font-family:sans-serif;" +
                   "direction:rtl;color:#a3392c;text-align:center;padding:20px;'>" +
                   "تعذّر التحقق من سلامة التطبيق.<br>يُرجى تثبيته من المصدر الرسمي.</body></html>";
        }
        InputStream is = getAssets().open("index.enc");
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] tmp = new byte[8192];
        int n;
        while ((n = is.read(tmp)) != -1) buf.write(tmp, 0, n);
        is.close();

        byte[] raw = buf.toByteArray();
        // First 16 bytes = IV, rest = ciphertext
        byte[] iv         = Arrays.copyOfRange(raw, 0, 16);
        byte[] ciphertext = Arrays.copyOfRange(raw, 16, raw.length);

        SecretKeySpec keySpec = new SecretKeySpec(buildKey(), "AES");
        IvParameterSpec  ivSpec = new IvParameterSpec(iv);
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
        byte[] plain = cipher.doFinal(ciphertext);

        return new String(plain, "UTF-8");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SplashScreen.installSplashScreen(this);
        super.onCreate(savedInstanceState);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        setContentView(R.layout.activity_main);
        // Edge-to-edge (API 35+): pad root view by system bar insets so content isn't clipped.
        final android.view.View __rootInsetView = findViewById(android.R.id.content);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(__rootInsetView, (v, windowInsets) -> {
            androidx.core.graphics.Insets bars = windowInsets.getInsets(
                androidx.core.view.WindowInsetsCompat.Type.systemBars()
                    | androidx.core.view.WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return windowInsets;
        });


        webView = findViewById(R.id.webView);
        WebSettings s = webView.getSettings();

        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        // setAllowFileAccessFromFileURLs & setAllowUniversalAccessFromFileURLs
        // intentionally NOT set — assets served securely via WebViewAssetLoader.
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();

        webView.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void openTadabbur(String url) {
                if (url == null) return;
                if (!url.contains("page=") || !url.contains("verse=")) {
                    runOnUiThread(() -> android.widget.Toast.makeText(
                        MainActivity.this,
                        "جارٍ تحميل بيانات التدبر، حاول مجدداً",
                        android.widget.Toast.LENGTH_SHORT).show());
                    return;
                }
                openTadabburUrl(url, "🌿 القرآن تدبر وعمل");
            }

            // Generic in-app browser window (reuses TadabburActivity's WebView shell)
            // for any external link that should open inside the app instead of the
            // phone's browser — e.g. the hadith explanation links to dorar.net.
            @android.webkit.JavascriptInterface
            public void openExternalPage(String url, String title) {
                if (url == null || (!url.startsWith("http://") && !url.startsWith("https://"))) return;
                openTadabburUrl(url, (title == null || title.isEmpty()) ? "🔗 عرض خارجي" : title);
            }

            @android.webkit.JavascriptInterface
            public void sendEmail(String to, String subject, String body) {
                runOnUiThread(() -> {
                    try {
                        Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("message/rfc822");
                        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
                        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
                        intent.putExtra(Intent.EXTRA_TEXT, body);
                        startActivity(Intent.createChooser(intent, "إرسال بريد إلكتروني"));
                    } catch (android.content.ActivityNotFoundException e) {
                        android.widget.Toast.makeText(MainActivity.this,
                            "لا يوجد تطبيق بريد مثبّت", android.widget.Toast.LENGTH_LONG).show();
                    }
                });
            }
        }, "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse response = assetLoader.shouldInterceptRequest(request.getUrl());
                if (response != null) return response;
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(android.webkit.WebView view, String url) {
                if (url.startsWith("mailto:")) {
                    Intent intent = new Intent(Intent.ACTION_SENDTO);
                    intent.setData(Uri.parse(url));
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivity(intent);
                    }
                    return true;
                }
                if (url.contains("altadabbur.com")) {
                    if (url.contains("page=") && url.contains("verse=")) {
                        openTadabburUrl(url, "🌿 القرآن تدبر وعمل");
                    }
                    return true;
                }
                if ((url.startsWith("http://") || url.startsWith("https://"))
                        && !url.contains("appassets.androidplatform.net")
                        && !url.contains("mp3quran.net")
                        && !url.contains("everyayah.com")) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    return true;
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient());

        // ── Decrypt and load ──────────────────────────────────────────────────
        try {
            String html = loadEncryptedPage();
            webView.loadDataWithBaseURL(
                "https://appassets.androidplatform.net/",
                html,
                "text/html",
                "UTF-8",
                null
            );
        } catch (Exception e) {
            // Fallback: should never happen in production
            webView.loadUrl("about:blank");
        }

        // Register the modern back-press handler (see checkOverlayThenMaybeExit
        // below) — this is what actually gets invoked now, not a deprecated
        // onBackPressed() override, which current Android versions may not
        // reliably call before falling through to the default "close app"
        // behavior.
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                checkOverlayThenMaybeExit();
            }
        });
    }

    private void openTadabburUrl(String url, String title) {
        runOnUiThread(() -> {
            Intent intent = new Intent(MainActivity.this, TadabburActivity.class);
            intent.putExtra("url", url);
            intent.putExtra("title", title);
            startActivity(intent);
        });
    }

    // Modern, reliable back-press handling. The old Activity.onBackPressed()
    // override is not guaranteed to be invoked on current Android versions —
    // predictive-back and the AndroidX back dispatcher route through
    // OnBackPressedCallback instead, and relying on the deprecated override
    // alone was causing back presses to fall straight through to the system
    // default (closing the app) instead of first checking whether a JS
    // overlay — like the hadith panel — should consume the press.
    private void checkOverlayThenMaybeExit() {
        webView.evaluateJavascript(
            "window.__closeTopOverlay ? (window.__closeTopOverlay() ? 'handled' : 'exit') : 'exit'",
            value -> {
                if (value == null || value.contains("exit")) {
                    runOnUiThread(MainActivity.this::finish);
                }
            }
        );
    }
}
