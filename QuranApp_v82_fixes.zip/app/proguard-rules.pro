# ═══════════════════════════════════════════════
# Proguard Rules — QuranAll App
# ═══════════════════════════════════════════════

# WebView — احتفظ بكل ما يتعلق بـ WebView
-keep class android.webkit.** { *; }
-keepclassmembers class * extends android.webkit.WebViewClient { *; }
-keepclassmembers class * extends android.webkit.WebChromeClient { *; }
-dontwarn android.webkit.**

# JavascriptInterface — ضروري جداً للأزرار
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Anonymous classes used as JS interfaces
-keepclassmembers class com.equran.quranall.MainActivity$* {
    public *;
}

# AppCompat
-keep class androidx.appcompat.** { *; }
-dontwarn androidx.**

# عام
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
