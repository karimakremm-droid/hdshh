#!/usr/bin/env python3
"""
QuranTopics Asset Encryptor
===========================
Run this script whenever you update index.html or the JS/CSS files.
It re-encrypts the assets and regenerates index.enc.

Usage:
    python3 encrypt_assets.py

Requirements:
    pip install cryptography
"""

import os, sys, secrets, base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

# ─── PATHS ────────────────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(SCRIPT_DIR, "app", "src", "main", "assets")

JS_PATH   = os.path.join(ASSETS_DIR, "assets", "index-JBEEVQCW.js")
CSS_PATH  = os.path.join(ASSETS_DIR, "assets", "index-Mq0mt_p_.css")
HTML_PATH = os.path.join(ASSETS_DIR, "index.html")
ENC_PATH  = os.path.join(ASSETS_DIR, "index.enc")
KEY_PATH  = os.path.join(SCRIPT_DIR, "encryption_key.hex")

# ─── CHECK SOURCE FILES ───────────────────────────────────────────────────────
missing = [p for p in [JS_PATH, CSS_PATH, HTML_PATH] if not os.path.exists(p)]
if missing:
    print("ERROR: Missing source files:")
    for p in missing: print(f"  {p}")
    print("\nPlace your updated index.html / JS / CSS back in the assets folder,")
    print("then run this script again.")
    sys.exit(1)

print("Reading source files...")
with open(JS_PATH,  'rb') as f: js_bytes = f.read()
with open(CSS_PATH, 'r',  encoding='utf-8') as f: css_src = f.read()
with open(HTML_PATH,'r',  encoding='utf-8') as f: html_src = f.read()

print(f"  JS:   {len(js_bytes):,} bytes")
print(f"  CSS:  {len(css_src.encode()):,} bytes")
print(f"  HTML: {len(html_src.encode()):,} bytes")

# ─── XOR OBFUSCATE JS ─────────────────────────────────────────────────────────
print("\nObfuscating JS...")
xor_key = secrets.token_bytes(32)
xored   = bytes([b ^ xor_key[i % 32] for i, b in enumerate(js_bytes)])
b64     = base64.b64encode(xored).decode('ascii')
xor_ints = ','.join(str(x) for x in xor_key)

obf_js = (
    f"(function(){{"
    f"var _k=[{xor_ints}];"
    f'var _b="{b64}";'
    f"var _d=atob(_b);"
    f"var _r='';"
    f"for(var _i=0;_i<_d.length;_i++)_r+=String.fromCharCode(_d.charCodeAt(_i)^_k[_i%32]);"
    f"(0,eval)(_r);"
    f"}})();"
)
print(f"  Obfuscated JS: {len(obf_js):,} bytes")

# ─── BUILD COMBINED HTML ──────────────────────────────────────────────────────
print("Building combined HTML...")
fetch_polyfill = """(function(){
var _f=window.fetch;
window.fetch=function(u,o){
if(typeof u==='string'&&u.startsWith('file://')){
return new Promise(function(res,rej){
var x=new XMLHttpRequest();
x.open('GET',u,true);x.responseType='text';
x.onload=function(){if(x.status===200||x.status===0){var b=x.responseText;res({ok:true,status:200,text:function(){return Promise.resolve(b);},json:function(){return Promise.resolve(JSON.parse(b));}})}else rej(new Error(x.status));};
x.onerror=function(){rej(new Error('err'));};x.send();
});}
return _f.apply(this,arguments);};})();"""

ayah_css = """.ayah-highlight{outline:2px solid #c9a84c!important;border-radius:12px;animation:_ahpulse 1.5s ease;}
@keyframes _ahpulse{0%,100%{background:transparent}30%{background:rgba(201,168,76,0.18)}}"""

combined = '\n'.join([
    '<!doctype html><html lang="ar" dir="rtl"><head>',
    '<meta charset="UTF-8"/>',
    '<meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=no"/>',
    '<title>مواضيع القرآن الكريم</title>',
    '<meta name="theme-color" content="#1a6b3a"/>',
    f'<style>{ayah_css}{css_src}</style>',
    f'<script>{fetch_polyfill}</script>',
    '</head><body><div id="root"></div>',
    f'<script>{obf_js}</script>',
    '</body></html>',
])
plaintext = combined.encode('utf-8')
print(f"  Combined HTML: {len(plaintext):,} bytes")

# ─── AES-256-CBC ENCRYPT ──────────────────────────────────────────────────────
print("Encrypting...")

# Load or generate key
if os.path.exists(KEY_PATH):
    with open(KEY_PATH) as f: aes_key = bytes.fromhex(f.read().strip())
    print(f"  Using existing key from {KEY_PATH}")
else:
    aes_key = secrets.token_bytes(32)
    with open(KEY_PATH, 'w') as f: f.write(aes_key.hex())
    print(f"  Generated new key → saved to {KEY_PATH}")

iv  = secrets.token_bytes(16)
pad = 16 - (len(plaintext) % 16)
padded = plaintext + bytes([pad] * pad)

cipher = Cipher(algorithms.AES(aes_key), modes.CBC(iv), backend=default_backend())
enc = cipher.encryptor()
ciphertext = enc.update(padded) + enc.finalize()

with open(ENC_PATH, 'wb') as f:
    f.write(iv + ciphertext)

print(f"  index.enc written: {len(iv)+len(ciphertext):,} bytes")

# ─── PRINT JAVA KEY ARRAY ─────────────────────────────────────────────────────
k = aes_key
print("\n" + "="*60)
print("⚠️  UPDATE MainActivity.java WITH THESE KEY VALUES:")
print("="*60)
print(f"\n_K1: {{'(byte)0x{k[0]:02x},(byte)0x{k[1]:02x},(byte)0x{k[2]:02x},(byte)0x{k[3]:02x},(byte)0x{k[4]:02x},(byte)0x{k[5]:02x},(byte)0x{k[6]:02x},(byte)0x{k[7]:02x}'}}")
print(f"_K2: {{'(byte)0x{k[8]:02x},(byte)0x{k[9]:02x},(byte)0x{k[10]:02x},(byte)0x{k[11]:02x},(byte)0x{k[12]:02x},(byte)0x{k[13]:02x},(byte)0x{k[14]:02x},(byte)0x{k[15]:02x}'}}")
print(f"_K3: {{'(byte)0x{k[16]:02x},(byte)0x{k[17]:02x},(byte)0x{k[18]:02x},(byte)0x{k[19]:02x},(byte)0x{k[20]:02x},(byte)0x{k[21]:02x},(byte)0x{k[22]:02x},(byte)0x{k[23]:02x}'}}")
print(f"_K4: {{'(byte)0x{k[24]:02x},(byte)0x{k[25]:02x},(byte)0x{k[26]:02x},(byte)0x{k[27]:02x},(byte)0x{k[28]:02x},(byte)0x{k[29]:02x},(byte)0x{k[30]:02x},(byte)0x{k[31]:02x}'}}")
print("\n✅ Done! Build the project in Android Studio.")
